Code is written together by Amir Eihab El Abidou, Omar Almassri, Arianit Paso in Visual studio code and later tested and then published in Android studio by a user.
